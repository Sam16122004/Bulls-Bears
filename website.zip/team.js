var teamarr=[
    {
        name: "Subcommittee Interview",
        designation: "2,3,4 September 2023",
        imgSRC:"img/Parva_jani.jpg"
    },
    {
        name: "Subcommittee Interview",
        designation: "2,3,4 September 2023",
        imgSRC:"img/Parva_jani.jpg"
    },
    {
        name: "Subcommittee Interview",
        designation: "2,3,4 September 2023",
        imgSRC:"img/Parva_jani.jpg"
    }
    ]
    function team(id){
        let load = "";
        for(i=0;i<teamarr.length;i++){
            load +=`<a href="" class="d-block TEAM-item rounded">
            <img src="${teamarr[i].imgSRC}" alt="">
            <div class="bg-white shadow-sm text-center p-4 position-relative mt-n5 mx-4">
                <h4 class="text-primary">"${teamarr[i].name}"</h4>
                <span class="text-body">"${teamarr[i].designation}"</span>
            </div>
        </a>`;
        }
        document.getElementById(id).innerHTML = load+document.getElementById(id).innerHTML;
    }
