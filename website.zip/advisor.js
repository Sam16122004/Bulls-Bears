var arrayAD = [
  {
    name: "Subcommittee Interview",
    desc: `My time with Bulls&Bears was wholesome - from starting as a Public Relations member to finishing as the club’s President. I had the good fortune of being involved during an online-to-offline transition and amongst a host of creative and management ideas. It has always been an aim to maximize the club’s scope and help spread basic financial understanding. More than a club, it is a living entity - with its ever expanding audience, superb events and fantastic members. Greatly appreciative of the times I spent with Bulls&Bears.
        Cheers, VD"`,
    imgSRC: "img/event-2.jpg",
  },
  {
    name: "Subcommittee Interview",
    desc: `My time with Bulls&Bears was wholesome - from starting as a Public Relations member to finishing as the club’s President. I had the good fortune of being involved during an online-to-offline transition and amongst a host of creative and management ideas. It has always been an aim to maximize the club’s scope and help spread basic financial understanding. More than a club, it is a living entity - with its ever expanding audience, superb events and fantastic members. Greatly appreciative of the times I spent with Bulls&Bears.
        Cheers, VD"`,
    imgSRC: "img/event-1.jpg",
  },
];
function advisor(id) {
  let load = "";
  for (i = 0; i < arrayAD.length; i++) {
    load += `<div class="testimonial-item p-4 p-lg-5">
            <p class="mb-4">${arrayAD[i].desc}</p>
            <div class="d-flex align-items-center justify-content-center">
                <img class="img-fluid flex-shrink-0" src="${arrayAD[i].imgSRC}" alt="">
                <div class="text-start ms-3">
                    <h5>${arrayAD[i].name}</h5>
                    <span class="text-primary">ADVISOR</span>
                </div>
            </div>
        </div>`;
  }
  console.log(document.getElementById(id).innerHTML)
  document.getElementById(id).innerHTML =
    load + document.getElementById(id).innerHTML;
}
